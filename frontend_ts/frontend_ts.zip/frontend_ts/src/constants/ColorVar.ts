//Stores colours for usage in Vis components

export default {
    blue: "#339AF0",
    lightblue: "#D0EBFF",
    green: "#51CF66",
    lightgreen: "#D3F9D8",
    red: "#FF6B6B",
    orange: "#FF922B"
}
const LollipopChart = () => {
  return <div className="vis-container">LollipopPlot</div>;
};

export default LollipopChart;

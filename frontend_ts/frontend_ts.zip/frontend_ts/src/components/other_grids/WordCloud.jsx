const WordCloud = () => {
  return <div className="vis-container">WordCloud</div>;
};

export default WordCloud;
